# Grocery List React App

## Setup Instructions

1. Install dependencies:
```bash
npm install
```

2. Start the development server:
```bash
npm start
```

## Features

- Add grocery items to the list
- Mark items as purchased
- Remove items from the list

